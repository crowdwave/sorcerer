#!/bin/sh
rm sorcerer.zip
jar -cvf sorcerer.zip *

