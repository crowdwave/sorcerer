#!/bin/sh
#
# Make an executable JAR file
#
# Run with java -jar sorcerer.jar
#
jar -cvfm sorcerer.jar m.txt sorcererII/*.class
