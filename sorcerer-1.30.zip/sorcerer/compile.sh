#!/bin/sh
#
# Compile all the source files ready to run with run.sh
#
javac sorcererII/*.java

