#!/bin/bash

# List of files and directories to delete
items=(
  "COMPUTER.TTF"
  "COMPUTER.eot"
  "IN.BIN"
  "IN.COM"
  "IN.TXT"
  "META-INF"
  "backgamm.html"
  "breakout.html"
  "chess.html"
  "chomp.html"
  "compile.sh"
  "defender.html"
  "disks"
  "exsb1.html"
  "first.snp"
  "galx.html"
  "images"
  "index.html"
  "instructions.html"
  "invaders.html"
  "jarit.sh"
  "java.policy.applet"
  "killopede.html"
  "m.txt"
  "mon.html"
  "oldIndex.html"
  "rom-packs"
  "roms"
  "run.sh"
  "screen-shots"
  "snake.html"
  "snaps"
  "sorcerer.jar"
  "sorcererII"
  "tape1"
  "tapes"
  "word.html"
)

# Loop through each item and delete it if it exists
for item in "${items[@]}"; do
  if [ -e "$item" ]; then
    if [ -d "$item" ]; then
      echo "Deleting directory: $item"
      rm -rf "$item"
    else
      echo "Deleting file: $item"
      rm -f "$item"
    fi
  fi
done

echo "Deletion complete."

