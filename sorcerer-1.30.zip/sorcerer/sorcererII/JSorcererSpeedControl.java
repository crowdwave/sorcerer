package sorcererII;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class JSorcererSpeedControl extends JBistableImageButton {

  private final Sorcerer _sorcerer;
  /**
   * 
   */
  private static final long serialVersionUID = -6220389993271537478L;

  public JSorcererSpeedControl(final Sorcerer sorcerer) throws IOException {
    super(ImageIO.read(new File("images/icon-fast-faint.png")),
          ImageIO.read(new File("images/icon-fast.png")),
          "Run full speed");
    _sorcerer = sorcerer;
  }
  
  @Override
  public boolean gotoState1() {
    _sorcerer.runFullSpeed(false);
    return true;
  }

  @Override
  public boolean gotoState2() {
    _sorcerer.runFullSpeed(true);
    return true;
  }

}
