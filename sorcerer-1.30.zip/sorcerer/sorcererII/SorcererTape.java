package sorcererII;

import java.io.*;

public interface SorcererTape
{
  public void rewind();
  public void motorOn(float baudRate);
  public void motorOff();
  public byte getByte() throws IOException;
  public void writeByte( byte b ) throws IOException;
}