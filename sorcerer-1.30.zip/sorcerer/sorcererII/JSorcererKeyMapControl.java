package sorcererII;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class JSorcererKeyMapControl extends JBistableImageButton {

  private final Sorcerer _sorcerer;
  /**
   * 
   */
  private static final long serialVersionUID = -6220389993271537478L;

  public JSorcererKeyMapControl(final Sorcerer sorcerer) throws IOException {
    super(ImageIO.read(new File("images/icon-key-faint.png")),
          ImageIO.read(new File("images/icon-key.png")),
          "Character keyboard map");
    _sorcerer = sorcerer;
  }
  
  @Override
  public boolean gotoState1() {
    _sorcerer.useHardKeys(true);
    return true;
  }

  @Override
  public boolean gotoState2() {
    _sorcerer.useHardKeys(false);
    return true;
  }
}
