package sorcererII;

import java.io.IOException;

public interface SorcererDisk {
  public byte read( int track, int sector, int offset );

  public void write( int track, int sector, int offset, byte data );

  public void activate() throws IOException;

  public void deactivate() throws IOException;
}
