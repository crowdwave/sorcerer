package sorcererII;

public class EndOfCassetteException extends Exception
{
}