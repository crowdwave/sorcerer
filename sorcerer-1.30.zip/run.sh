#!/bin/sh
#
# Run the emulator from the class files
#
# In this mode file access to the disk images etc is possible
#
java sorcererII.SorcererFrame 

